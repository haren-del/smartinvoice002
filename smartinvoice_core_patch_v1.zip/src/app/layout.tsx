import './globals.css';
import { ThemeProvider } from '@/components/ThemeProvider';
import Header from '@/components/Header';
import { SupabaseProvider } from '@/components/SupabaseProvider';

export const metadata = { title: 'bizInvoice', description: 'Modern invoicing made simple' };

export default function RootLayout({ children }: { children: React.ReactNode }){
  return (
    <html lang="en">
      <body>
        <SupabaseProvider>
          <ThemeProvider>
            <Header />
            <main className="p-6">{children}</main>
          </ThemeProvider>
        </SupabaseProvider>
      </body>
    </html>
  );
}
