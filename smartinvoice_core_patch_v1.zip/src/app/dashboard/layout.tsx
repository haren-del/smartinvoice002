"use client";
import Sidebar from "@/components/Sidebar";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabaseClient";

export default function DashboardLayout({ children }: { children: React.ReactNode }){
  const router = useRouter();
  const [loading,setLoading] = useState(true);

  useEffect(()=>{
    let mounted = true;
    (async ()=>{
      const { data:{ session } } = await supabase.auth.getSession();
      if(!session?.user){ router.replace('/auth/login'); return; }
      if(mounted) setLoading(false);
    })();
    return ()=>{ mounted = false; };
  },[router]);

  if(loading) return <div className="flex items-center justify-center min-h-screen">Loading dashboard...</div>;

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <main className="flex-1 p-6 bg-[var(--background)] overflow-auto">{children}</main>
    </div>
  );
}
